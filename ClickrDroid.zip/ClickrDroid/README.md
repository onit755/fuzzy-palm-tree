# ClickrDroid

A MacroDroid-style block automation app with a Klickr-style auto-clicker, built
with Kotlin + Jetpack Compose. Ready to open in Android Studio.

## Open in Android Studio

1. **File → Open** and select this folder.
2. Let Gradle sync (it will download Gradle 8.9, AGP 8.5.2, Kotlin 2.0).
3. Plug in a device (or emulator running Android 7.0+) and press **Run**.
4. After installing:
   - Open the app once.
   - Go to **Settings → Accessibility → ClickrDroid** and turn it on.
     Auto-clicking other apps is **only** possible through the Accessibility
     API — Android does not allow it any other way without root.
5. Build a macro: tap **New macro**, then **Add block** to stack:
   - **Tap** — taps absolute screen coords (use any "Show pointer location"
     developer option to pick coordinates).
   - **Swipe** — gesture from point A to B.
   - **Wait** — pause N ms.
   - **Launch app** — pick from installed apps.
   - **Repeat** — loop N times (currently linear; nested children planned).
   - **Find text & tap** — scans the foreground UI for visible text and taps
     the matching node (more robust than fixed coords).
   - **Toast** — debug helper.
6. Hit **Run now** to execute, or tap the clock icon to schedule a one-shot
   or recurring run.

## Project layout

```
app/src/main/java/com/clickrdroid/app/
├── MainActivity.kt
├── model/Block.kt              # Macro + block data classes (kotlinx.serialization)
├── data/MacroRepository.kt     # JSON file-backed store under app's internal dir
├── service/
│   └── ClickerAccessibilityService.kt   # Dispatches taps/swipes/find-text
├── scheduler/
│   ├── MacroScheduler.kt       # AlarmManager wrapper
│   ├── MacroAlarmReceiver.kt   # Fires the macro at scheduled time
│   └── BootReceiver.kt         # Re-arms schedules after reboot
├── util/InstalledApps.kt       # Enumerates launcher apps via PackageManager
└── ui/
    ├── AppNav.kt
    ├── theme/Theme.kt
    ├── screens/
    │   ├── MacroListScreen.kt
    │   └── EditorScreen.kt
    └── components/
        ├── BlockCard.kt
        ├── AddBlockSheet.kt
        └── ScheduleSheet.kt
```

## What's stubbed vs. complete

Complete:
- Block-based editor, persistence, reordering, deletion.
- Tap, swipe, wait, launch app, find-text-and-tap, toast, linear repeat.
- One-shot and repeating alarms via AlarmManager; survives reboot.
- App picker that enumerates installed launcher apps.

Stubbed / future work:
- Nested children inside `Repeat` (data model supports it; UI shows a flat list).
- Conditional blocks (If/Else), variables, triggers other than schedule
  (battery, Wi-Fi, notification arrival — MacroDroid-style).
- Image-template matching ("click when this icon appears") — needs
  MediaProjection + OpenCV; non-trivial.
- Foreground service notification while a macro runs.
- Launcher icon (uses platform default until you drop a `mipmap/ic_launcher`).
- `gradle/wrapper/gradle-wrapper.jar` is not bundled — Android Studio
  generates it on first sync, or run `gradle wrapper` once.

## Permissions used

- `BIND_ACCESSIBILITY_SERVICE` — granted by user in Settings, required for
  dispatching gestures on other apps.
- `QUERY_ALL_PACKAGES` — to list installed apps in the picker (Android 11+).
- `SCHEDULE_EXACT_ALARM` / `USE_EXACT_ALARM` — precise scheduling.
- `RECEIVE_BOOT_COMPLETED` — restore schedules after reboot.
- `POST_NOTIFICATIONS`, `FOREGROUND_SERVICE` — reserved for a future
  foreground-service notification.

No internet permission is requested — everything runs on-device.
