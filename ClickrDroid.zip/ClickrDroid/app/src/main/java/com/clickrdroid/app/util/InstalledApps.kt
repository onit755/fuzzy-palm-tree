package com.clickrdroid.app.util

import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo

data class AppEntry(val label: String, val packageName: String)

object InstalledApps {
    fun list(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val results: List<ResolveInfo> = pm.queryIntentActivities(intent, 0)
        return results.map {
            AppEntry(
                label = it.loadLabel(pm).toString(),
                packageName = it.activityInfo.packageName
            )
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }
}
