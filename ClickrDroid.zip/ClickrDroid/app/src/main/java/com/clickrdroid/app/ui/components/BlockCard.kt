package com.clickrdroid.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import com.clickrdroid.app.model.Block

@Composable
fun BlockCard(
    index: Int,
    block: Block,
    onMoveUp: (() -> Unit)?,
    onMoveDown: (() -> Unit)?,
    onDelete: () -> Unit,
    onChange: (Block) -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AssistChip(onClick = {}, label = { Text("#${index + 1}") })
                Spacer(Modifier.width(8.dp))
                Text(block.typeLabel(), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { onMoveUp?.invoke() }, enabled = onMoveUp != null) {
                    Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Move up")
                }
                IconButton(onClick = { onMoveDown?.invoke() }, enabled = onMoveDown != null) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Move down")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                }
            }
            Spacer(Modifier.height(8.dp))
            BlockEditor(block, onChange)
        }
    }
}

private fun Block.typeLabel(): String = when (this) {
    is Block.Tap -> "Tap"
    is Block.Swipe -> "Swipe"
    is Block.Wait -> "Wait"
    is Block.LaunchApp -> "Launch app"
    is Block.Repeat -> "Repeat"
    is Block.FindTextAndTap -> "Find text & tap"
    is Block.Toast -> "Toast"
}

@Composable
private fun BlockEditor(block: Block, onChange: (Block) -> Unit) {
    when (block) {
        is Block.Tap -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField("X", block.x) { onChange(block.copy(x = it)) }
            NumberField("Y", block.y) { onChange(block.copy(y = it)) }
            NumberField("Hold ms", block.durationMs.toInt()) { onChange(block.copy(durationMs = it.toLong())) }
        }
        is Block.Swipe -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("X1", block.x1) { onChange(block.copy(x1 = it)) }
                NumberField("Y1", block.y1) { onChange(block.copy(y1 = it)) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("X2", block.x2) { onChange(block.copy(x2 = it)) }
                NumberField("Y2", block.y2) { onChange(block.copy(y2 = it)) }
                NumberField("ms", block.durationMs.toInt()) { onChange(block.copy(durationMs = it.toLong())) }
            }
        }
        is Block.Wait -> NumberField("Milliseconds", block.ms.toInt()) {
            onChange(block.copy(ms = it.toLong()))
        }
        is Block.LaunchApp -> Column {
            Text(block.label.ifBlank { block.packageName },
                style = MaterialTheme.typography.bodyMedium)
            Text(block.packageName,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        is Block.Repeat -> NumberField("Times", block.times) {
            onChange(block.copy(times = it.coerceAtLeast(1)))
        }
        is Block.FindTextAndTap -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = block.text,
                onValueChange = { onChange(block.copy(text = it)) },
                label = { Text("Text") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            NumberField("Timeout ms", block.timeoutMs.toInt()) {
                onChange(block.copy(timeoutMs = it.toLong()))
            }
        }
        is Block.Toast -> OutlinedTextField(
            value = block.message,
            onValueChange = { onChange(block.copy(message = it)) },
            label = { Text("Message") },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun NumberField(label: String, value: Int, onValue: (Int) -> Unit) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = {
            text = it.filter { ch -> ch.isDigit() || ch == '-' }
            onValue(text.toIntOrNull() ?: 0)
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.width(110.dp)
    )
}
