package com.clickrdroid.app.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.clickrdroid.app.data.Repo

/** After reboot, re-arm all enabled schedules. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val macros = Repo.get(context).macros.value
        macros.filter { it.schedule?.enabled == true }.forEach {
            MacroScheduler.schedule(context, it)
        }
    }
}
