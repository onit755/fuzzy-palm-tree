package com.clickrdroid.app.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.clickrdroid.app.data.Repo
import com.clickrdroid.app.model.Macro
import com.clickrdroid.app.service.ClickerAccessibilityService
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MacroListScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val repo = remember { Repo.get(ctx) }
    val macros by repo.macros.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ClickrDroid", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }) { Icon(Icons.Default.Settings, contentDescription = "Accessibility settings") }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    val m = Macro(id = UUID.randomUUID().toString(), name = "New macro")
                    repo.upsert(m)
                    nav.navigate("editor/${m.id}")
                },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("New macro") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .fillMaxSize()
        ) {
            if (!ClickerAccessibilityService.isRunning()) {
                AssistChipsRow(
                    onEnable = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                )
            }
            if (macros.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No macros yet — tap “New macro”.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(macros, key = { it.id }) { macro ->
                        MacroRow(
                            macro = macro,
                            onOpen = { nav.navigate("editor/${macro.id}") },
                            onRun = { ClickerAccessibilityService.runMacroOrToast(ctx, macro) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AssistChipsRow(onEnable: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("Accessibility service is off", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Macros can't tap other apps until you enable the ClickrDroid accessibility service.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(onClick = onEnable) { Text("Open Accessibility settings") }
        }
    }
}

@Composable
private fun MacroRow(macro: Macro, onOpen: () -> Unit, onRun: () -> Unit) {
    ElevatedCard(onClick = onOpen, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(macro.name, fontWeight = FontWeight.SemiBold)
                Text(
                    "${macro.blocks.size} block(s)" +
                        if (macro.schedule?.enabled == true) " • scheduled" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            FilledIconButton(onClick = onRun) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Run")
            }
        }
    }
}
