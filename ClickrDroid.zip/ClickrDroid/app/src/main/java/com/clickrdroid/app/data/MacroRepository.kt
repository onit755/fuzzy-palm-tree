package com.clickrdroid.app.data

import android.content.Context
import com.clickrdroid.app.model.Macro
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Simple file-backed repository for macros. Keeps things explicit and easy
 * to reason about — one JSON file under app's internal storage.
 */
class MacroRepository(private val ctx: Context) {
    private val file: File get() = File(ctx.filesDir, "macros.json")
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    private val _macros = MutableStateFlow(load())
    val macros: StateFlow<List<Macro>> = _macros

    private fun load(): List<Macro> = runCatching {
        if (!file.exists()) emptyList()
        else json.decodeFromString<List<Macro>>(file.readText())
    }.getOrDefault(emptyList())

    fun persist(list: List<Macro>) {
        _macros.value = list
        runCatching { file.writeText(json.encodeToString(list)) }
    }

    fun upsert(macro: Macro) {
        val list = _macros.value.toMutableList()
        val idx = list.indexOfFirst { it.id == macro.id }
        if (idx >= 0) list[idx] = macro else list.add(macro)
        persist(list)
    }

    fun delete(id: String) = persist(_macros.value.filterNot { it.id == id })

    fun find(id: String): Macro? = _macros.value.firstOrNull { it.id == id }
}

object Repo {
    @Volatile private var instance: MacroRepository? = null
    fun get(ctx: Context): MacroRepository = instance ?: synchronized(this) {
        instance ?: MacroRepository(ctx.applicationContext).also { instance = it }
    }
}
