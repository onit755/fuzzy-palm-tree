package com.clickrdroid.app.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.clickrdroid.app.data.Repo
import com.clickrdroid.app.service.ClickerAccessibilityService

class MacroAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(EXTRA_MACRO_ID) ?: return
        val macro = Repo.get(context).find(id) ?: return
        ClickerAccessibilityService.runMacroOrToast(context, macro)
        // If the macro repeats, reschedule its next run.
        macro.schedule?.takeIf { it.enabled && it.repeatMs > 0 }?.let {
            MacroScheduler.schedule(context, macro.copy(
                schedule = it.copy(nextRunAt = System.currentTimeMillis() + it.repeatMs)
            ))
        }
    }
    companion object { const val EXTRA_MACRO_ID = "macro_id" }
}
