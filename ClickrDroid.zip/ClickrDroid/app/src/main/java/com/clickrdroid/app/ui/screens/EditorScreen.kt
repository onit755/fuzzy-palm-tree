package com.clickrdroid.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.clickrdroid.app.data.Repo
import com.clickrdroid.app.model.Block
import com.clickrdroid.app.model.Macro
import com.clickrdroid.app.model.Schedule
import com.clickrdroid.app.scheduler.MacroScheduler
import com.clickrdroid.app.service.ClickerAccessibilityService
import com.clickrdroid.app.ui.components.AddBlockSheet
import com.clickrdroid.app.ui.components.BlockCard
import com.clickrdroid.app.ui.components.ScheduleSheet

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(nav: NavHostController, macroId: String) {
    val ctx = LocalContext.current
    val repo = remember { Repo.get(ctx) }
    val macros by repo.macros.collectAsState()
    val original = macros.firstOrNull { it.id == macroId } ?: return

    var name by remember(original.id) { mutableStateOf(original.name) }
    var blocks by remember(original.id) { mutableStateOf(original.blocks) }
    var schedule by remember(original.id) { mutableStateOf(original.schedule) }
    var showAdd by remember { mutableStateOf(false) }
    var showSchedule by remember { mutableStateOf(false) }

    fun persist() {
        val updated = Macro(macroId, name.ifBlank { "Untitled" }, blocks, schedule)
        repo.upsert(updated)
        if (schedule?.enabled == true) MacroScheduler.schedule(ctx, updated)
        else MacroScheduler.cancel(ctx, macroId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit macro") },
                navigationIcon = {
                    IconButton(onClick = { persist(); nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showSchedule = true }) {
                        Icon(Icons.Default.Schedule, contentDescription = "Schedule")
                    }
                    IconButton(onClick = {
                        repo.delete(macroId); MacroScheduler.cancel(ctx, macroId); nav.popBackStack()
                    }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Add block") }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).padding(horizontal = 16.dp).fillMaxSize()
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it; persist() },
                label = { Text("Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(onClick = {
                    persist()
                    ClickerAccessibilityService.runMacroOrToast(ctx, Macro(macroId, name, blocks, schedule))
                }) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp)); Text("Run now")
                }
                Spacer(Modifier.width(8.dp))
                if (schedule?.enabled == true) {
                    AssistChip(onClick = { showSchedule = true }, label = { Text("Scheduled") })
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Blocks", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            if (blocks.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Add your first block to build a macro.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(blocks, key = { i, _ -> i }) { index, block ->
                        BlockCard(
                            index = index,
                            block = block,
                            onMoveUp = if (index == 0) null else {{
                                val m = blocks.toMutableList()
                                val tmp = m[index - 1]; m[index - 1] = m[index]; m[index] = tmp
                                blocks = m; persist()
                            }},
                            onMoveDown = if (index == blocks.lastIndex) null else {{
                                val m = blocks.toMutableList()
                                val tmp = m[index + 1]; m[index + 1] = m[index]; m[index] = tmp
                                blocks = m; persist()
                            }},
                            onDelete = {
                                blocks = blocks.toMutableList().also { it.removeAt(index) }; persist()
                            },
                            onChange = { updated ->
                                blocks = blocks.toMutableList().also { it[index] = updated }; persist()
                            }
                        )
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddBlockSheet(
            onDismiss = { showAdd = false },
            onPick = { newBlock ->
                blocks = blocks + newBlock
                showAdd = false
                persist()
            }
        )
    }
    if (showSchedule) {
        ScheduleSheet(
            current = schedule ?: Schedule(),
            onDismiss = { showSchedule = false },
            onSave = { newSchedule ->
                schedule = newSchedule
                showSchedule = false
                persist()
            }
        )
    }
}
