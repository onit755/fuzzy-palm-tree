package com.clickrdroid.app.scheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.clickrdroid.app.model.Macro

object MacroScheduler {

    private fun pendingIntent(ctx: Context, macroId: String): PendingIntent {
        val intent = Intent(ctx, MacroAlarmReceiver::class.java).apply {
            putExtra(MacroAlarmReceiver.EXTRA_MACRO_ID, macroId)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(ctx, macroId.hashCode(), intent, flags)
    }

    fun schedule(ctx: Context, macro: Macro) {
        val schedule = macro.schedule ?: return
        if (!schedule.enabled || schedule.nextRunAt <= 0L) return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(ctx, macro.id)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.set(AlarmManager.RTC_WAKEUP, schedule.nextRunAt, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, schedule.nextRunAt, pi)
        }
    }

    fun cancel(ctx: Context, macroId: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(ctx, macroId))
    }
}
