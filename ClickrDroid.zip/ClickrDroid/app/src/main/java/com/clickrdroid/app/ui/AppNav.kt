package com.clickrdroid.app.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.clickrdroid.app.ui.screens.EditorScreen
import com.clickrdroid.app.ui.screens.MacroListScreen

@Composable
fun AppNav(nav: NavHostController) {
    NavHost(navController = nav, startDestination = "list") {
        composable("list") { MacroListScreen(nav) }
        composable("editor/{id}") { backStack ->
            val id = backStack.arguments?.getString("id") ?: return@composable
            EditorScreen(nav, id)
        }
    }
}
