package com.clickrdroid.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import com.clickrdroid.app.model.Block
import com.clickrdroid.app.model.Macro
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The brains of auto-clicking. The Accessibility API is the only sanctioned
 * way to dispatch taps/gestures on top of other apps without root.
 *
 * Activate via Settings → Accessibility → ClickrDroid.
 */
class ClickerAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(Dispatchers.Default)
    private var currentJob: Job? = null

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        currentJob?.cancel()
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* no-op */ }
    override fun onInterrupt() { currentJob?.cancel() }

    fun runMacro(macro: Macro) {
        currentJob?.cancel()
        currentJob = scope.launch { execute(macro.blocks) }
    }

    private suspend fun execute(blocks: List<Block>) {
        for (block in blocks) {
            when (block) {
                is Block.Tap -> tap(block.x, block.y, block.durationMs)
                is Block.Swipe -> swipe(block.x1, block.y1, block.x2, block.y2, block.durationMs)
                is Block.Wait -> delay(block.ms)
                is Block.LaunchApp -> launchApp(block.packageName)
                is Block.Repeat -> repeat(block.times) { execute(block.children) }
                is Block.FindTextAndTap -> findAndTap(block.text, block.timeoutMs)
                is Block.Toast -> withContext(Dispatchers.Main) {
                    Toast.makeText(applicationContext, block.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun tap(x: Int, y: Int, durationMs: Long) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1)))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long) {
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1)))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun launchApp(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private suspend fun findAndTap(text: String, timeoutMs: Long) {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            val root: AccessibilityNodeInfo? = rootInActiveWindow
            val node = root?.findAccessibilityNodeInfosByText(text)?.firstOrNull()
            if (node != null) {
                if (!node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    val rect = android.graphics.Rect()
                    node.getBoundsInScreen(rect)
                    tap(rect.centerX(), rect.centerY(), 50)
                }
                return
            }
            delay(250)
        }
    }

    companion object {
        @Volatile private var instance: ClickerAccessibilityService? = null
        fun isRunning(): Boolean = instance != null
        fun get(): ClickerAccessibilityService? = instance

        /** Convenience to fire a macro from anywhere (UI, scheduler, etc.). */
        fun runMacroOrToast(ctx: Context, macro: Macro) {
            val svc = instance
            if (svc == null) {
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(
                        ctx,
                        "Enable ClickrDroid Accessibility Service first",
                        Toast.LENGTH_LONG
                    ).show()
                }
                return
            }
            svc.runMacro(macro)
        }
    }
}
