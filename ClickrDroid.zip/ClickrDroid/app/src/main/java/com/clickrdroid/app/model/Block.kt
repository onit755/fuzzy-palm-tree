package com.clickrdroid.app.model

import kotlinx.serialization.Serializable

@Serializable
sealed class Block {
    @Serializable
    data class Tap(val x: Int, val y: Int, val durationMs: Long = 50) : Block()

    @Serializable
    data class Swipe(val x1: Int, val y1: Int, val x2: Int, val y2: Int, val durationMs: Long = 300) : Block()

    @Serializable
    data class Wait(val ms: Long) : Block()

    @Serializable
    data class LaunchApp(val packageName: String, val label: String = "") : Block()

    @Serializable
    data class Repeat(val times: Int, val children: List<Block>) : Block()

    @Serializable
    data class FindTextAndTap(val text: String, val timeoutMs: Long = 5000) : Block()

    @Serializable
    data class Toast(val message: String) : Block()
}

@Serializable
data class Macro(
    val id: String,
    val name: String,
    val blocks: List<Block> = emptyList(),
    val schedule: Schedule? = null
)

@Serializable
data class Schedule(
    val enabled: Boolean = false,
    /** epoch millis of next trigger */
    val nextRunAt: Long = 0L,
    /** repeat interval in millis (0 = one shot) */
    val repeatMs: Long = 0L
)
