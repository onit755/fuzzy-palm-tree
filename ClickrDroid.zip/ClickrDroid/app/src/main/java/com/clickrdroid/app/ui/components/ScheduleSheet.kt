package com.clickrdroid.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.clickrdroid.app.model.Schedule
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleSheet(
    current: Schedule,
    onDismiss: () -> Unit,
    onSave: (Schedule) -> Unit
) {
    var enabled by remember { mutableStateOf(current.enabled) }
    var delayMinutes by remember { mutableStateOf("5") }
    var repeatMinutes by remember { mutableStateOf((current.repeatMs / 60000L).toString()) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Schedule", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Switch(checked = enabled, onCheckedChange = { enabled = it })
                Spacer(Modifier.width(8.dp))
                Text(if (enabled) "On" else "Off")
            }
            OutlinedTextField(
                value = delayMinutes,
                onValueChange = { delayMinutes = it.filter(Char::isDigit) },
                label = { Text("Start in (minutes)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = repeatMinutes,
                onValueChange = { repeatMinutes = it.filter(Char::isDigit) },
                label = { Text("Repeat every (minutes, 0 = once)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            if (current.enabled && current.nextRunAt > 0) {
                val fmt = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
                Text("Currently next run: ${fmt.format(Date(current.nextRunAt))}",
                    style = MaterialTheme.typography.bodySmall)
            }
            Button(
                onClick = {
                    val delay = (delayMinutes.toLongOrNull() ?: 0L) * 60_000L
                    val repeat = (repeatMinutes.toLongOrNull() ?: 0L) * 60_000L
                    onSave(
                        Schedule(
                            enabled = enabled,
                            nextRunAt = if (enabled) System.currentTimeMillis() + delay else 0L,
                            repeatMs = repeat
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save schedule") }
        }
    }
}
