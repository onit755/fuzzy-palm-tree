package com.clickrdroid.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.clickrdroid.app.model.Block
import com.clickrdroid.app.util.AppEntry
import com.clickrdroid.app.util.InstalledApps

private data class BlockOption(
    val label: String, val icon: ImageVector,
    val build: () -> Block
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddBlockSheet(onDismiss: () -> Unit, onPick: (Block) -> Unit) {
    var pickingApp by remember { mutableStateOf(false) }
    val options = listOf(
        BlockOption("Tap", Icons.Default.TouchApp) { Block.Tap(500, 500) },
        BlockOption("Swipe", Icons.Default.SwipeRight) { Block.Swipe(200, 800, 800, 800) },
        BlockOption("Wait", Icons.Default.Timer) { Block.Wait(1000) },
        BlockOption("Launch app", Icons.Default.Apps) { Block.LaunchApp("") },
        BlockOption("Repeat", Icons.Default.Repeat) { Block.Repeat(3, emptyList()) },
        BlockOption("Find text & tap", Icons.Default.Search) { Block.FindTextAndTap("") },
        BlockOption("Toast", Icons.Default.Notifications) { Block.Toast("Hello") },
    )

    ModalBottomSheet(onDismissRequest = onDismiss) {
        if (pickingApp) {
            AppPicker(onCancel = { pickingApp = false }, onPick = { entry ->
                onPick(Block.LaunchApp(entry.packageName, entry.label))
            })
        } else {
            Column(Modifier.padding(16.dp)) {
                Text("Add a block", fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                options.forEach { opt ->
                    ListItem(
                        leadingContent = { Icon(opt.icon, contentDescription = null) },
                        headlineContent = { Text(opt.label) },
                        modifier = Modifier.clickable {
                            if (opt.label == "Launch app") pickingApp = true
                            else onPick(opt.build())
                        }
                    )
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun AppPicker(onCancel: () -> Unit, onPick: (AppEntry) -> Unit) {
    val ctx = LocalContext.current
    val apps by produceState<List<AppEntry>>(initialValue = emptyList()) {
        value = InstalledApps.list(ctx)
    }
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onCancel) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text("Pick an app", fontWeight = FontWeight.SemiBold)
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("Search") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
        val filtered = apps.filter {
            query.isBlank() || it.label.contains(query, true) || it.packageName.contains(query, true)
        }
        LazyColumn(modifier = Modifier.heightIn(max = 480.dp)) {
            items(filtered, key = { it.packageName }) { app ->
                ListItem(
                    headlineContent = { Text(app.label) },
                    supportingContent = { Text(app.packageName) },
                    modifier = Modifier.clickable { onPick(app) }
                )
                HorizontalDivider()
            }
        }
    }
}
